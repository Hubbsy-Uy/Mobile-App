package com.example.test_four

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.test_four.Adapter.HorizontalRecyclerView

class MainActivity : AppCompatActivity(){

    private lateinit var newRecyclerView: RecyclerView
    private lateinit var adapter: HorizontalRecyclerView
    private lateinit var newArrayList: ArrayList<News>
    private var tts: TextToSpeech? = null
    lateinit var heading: Array<String>
    lateinit var content: Array<String>
    lateinit var greetings: Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        heading = arrayOf(
            "Lesson 1",
            "Lesson 2",
            "Lesson 3",
            "Lesson 4",
            "Lesson 5"
        )

        greetings = arrayOf(
            getString(R.string.greet_a),
            getString(R.string.greet_b),
            getString(R.string.greet_c),
            getString(R.string.greet_d),
            getString(R.string.greet_e)
        )

        content = arrayOf(
            getString(R.string.first),
            getString(R.string.second),
            getString(R.string.third),
            getString(R.string.fourth),
            getString(R.string.fifth)
        )

        newArrayList = arrayListOf<News>()
        newRecyclerView = findViewById(R.id.recyclerView)
        adapter = HorizontalRecyclerView(newArrayList, greetings) // Pass greetings to adapter
        newRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        newRecyclerView.adapter = adapter

        getUserdata() // Call this after setting up the RecyclerView
    }



    private fun getUserdata() {
        // Loop through the headings and content and populate the newArrayList with News objects
        for (i in heading.indices) {
            val news = News(heading[i], content[i]) // Add content to each News object
            newArrayList.add(news)
        }

        // Notify the adapter of the data change
        adapter.notifyDataSetChanged()
    }
}
