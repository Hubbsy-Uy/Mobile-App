package com.example.test_four

data class News(var heading: String, var content: String)

