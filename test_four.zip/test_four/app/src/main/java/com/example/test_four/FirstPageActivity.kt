package com.example.test_four

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class FirstPageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course)

        // Retrieve the lesson title, content, and greeting
        val lessonTitle = intent.getStringExtra("LESSON_TITLE")
        val lessonContent = intent.getStringExtra("LESSON_CONTENT")
        val lessonGreeting = intent.getStringExtra("LESSON_GREETING")

        // Set the text in the TextViews
        findViewById<TextView>(R.id.textView).text = lessonTitle ?: "Default Lesson Title"
        findViewById<TextView>(R.id.textView2).text = lessonGreeting ?: "Default Greeting"

        // Display the greeting (you may want to add another TextView for this)
        findViewById<TextView>(R.id.textView3).text = lessonContent ?: "Default Content"

        // Set up the back button
        findViewById<Button>(R.id.backButton).setOnClickListener {
            finish() // Closes the current activity and returns to the previous one
        }
    }
}
