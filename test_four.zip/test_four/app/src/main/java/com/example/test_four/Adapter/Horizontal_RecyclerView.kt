package com.example.test_four.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.test_four.News
import com.example.test_four.R
import com.example.test_four.FirstPageActivity

class HorizontalRecyclerView(private val courseList: ArrayList<News>, private val greetings: Array<String>) : RecyclerView.Adapter<HorizontalRecyclerView.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.tvHeading)
        val startButton: Button = itemView.findViewById(R.id.startButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.list_course, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = courseList[position]
        holder.title.text = currentItem.heading

        // Set an OnClickListener for the button
        holder.startButton.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, FirstPageActivity::class.java)
            intent.putExtra("LESSON_TITLE", currentItem.heading) // Pass the title
            intent.putExtra("LESSON_CONTENT", currentItem.content) // Pass the content
            intent.putExtra("LESSON_GREETING", greetings[position]) // Pass the corresponding greeting
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return courseList.size
    }
}
